import React from 'react'
import ClassHome from "../Component/Homestyle/Sectionone.module.scss"
import Sectionone from '../Component/Sectionone'
import Sectiontwo from '../Component/Sectiontwo'
import Sectionthree from '../Component/Sectionthree'
import Sectionfour from '../Component/Sectionfour'
import Sectionfive from '../Component/Sectionfive'
import SectionSix from '../Component/SectionSix'
import Sectionseven from '../Component/Sectionseven'
// import Class from "../Component/Navbar.module.scss"


export const Home = () => {
  return (
    <>
<Sectionone/>
<Sectiontwo/>
<Sectionthree/>
<Sectionfour/>
<Sectionfive/>
<SectionSix/>
<Sectionseven/>
    
    </>
  )
}
