
function Footer() {
    return (
        <div>
            <h3>2022 all rights reserved to Base Labs</h3>
            <h3>Terms of use</h3>
            <h3>Privacy</h3>
            <h3>Support</h3>
        </div>
    )
}
export default Footer;